<!DOCTYPE html>
<html lang="en">

<head>
<?php echo $__env->make('include.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</head>

<body class="fixed-nav sticky-footer bg-dark" id="page-top">
  <!-- Navigation-->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top" id="mainNav">
    <?php echo $__env->make('include.slider', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  </nav>
  <div class="content-wrapper">
    <div class="container-fluid">
      <!-- Example DataTables Card-->
      <div class="card mb-3">
        <div class="card-header">
          <i class="fa fa-table"></i> Cashflow View</div>
        <div class="card-body">
          <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
              <thead>
                <tr>
                  <th>User</th>
                  <th>Information</th>
                  <th>Type</th>
                  <th>Cash</th>
                  <th>Date</th>
                </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                <tr>
                  <td><?php echo e($u->user->name); ?></td>
                  <td><?php echo e($u->information); ?></td>
                  <td><?php if( $u->cash > 0): ?> In <?php elseif($u->cash < 0): ?> Out <?php endif; ?></td>
                  <td><?php echo e($u->cash); ?></td>
                  <td><?php echo e($u->date); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
              </tbody>
            </table>
          </div>
        </div>
        <div class="card-footer small text-muted">Updated yesterday at 11:59 PM</div>
      </div>
    </div>
    <!-- /.container-fluid-->
    <!-- /.content-wrapper-->
    <?php echo $__env->make('include.foot', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('include.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  </div>
</body>

</html>
