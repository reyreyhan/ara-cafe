<!DOCTYPE html>
<html lang="en">

<head>
<?php echo $__env->make('include.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</head>

<body class="bg-dark">
  <div class="container">
    <div class="card card-login mx-auto mt-5">
      <div class="card-header">Login</div>
      <div class="card-body">
        <form action="<?php echo e(url('/check')); ?>" method="post" enctype="multipart/form-data">
          <?php echo e(csrf_field()); ?>

          <?php echo e(method_field('post')); ?>

          <div class="form-group">
            <label>Username</label>
            <input class="form-control" name="username" type="text" placeholder="username" required>
          </div>
          <div class="form-group">
            <label>Password</label>
            <input class="form-control" name="password" type="password" placeholder="password" required>
          </div>
          <button type="submit" class="btn btn-primary">Login</button>
        </form>
      </div>
    </div>
  </div>
<?php echo $__env->make('include.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</body>

</html>
