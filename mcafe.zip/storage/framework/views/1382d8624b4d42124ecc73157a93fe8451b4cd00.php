<!DOCTYPE html>
<html lang="en">

<head>
<?php echo $__env->make('include.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</head>

<body class="fixed-nav sticky-footer bg-dark" id="page-top">
  <!-- Navigation-->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top" id="mainNav">
    <?php echo $__env->make('include.slider', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  </nav>
  <div class="content-wrapper">
    <div class="container-fluid">
      <!-- Breadcrumbs-->
      <div class="row">
        <div class="col-6">
          EMPTY
        </div>
      </div>
    </div>
    <!-- /.container-fluid-->
    <!-- /.content-wrapper-->
    <?php echo $__env->make('include.foot', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('include.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  </div>
</body>

</html>
