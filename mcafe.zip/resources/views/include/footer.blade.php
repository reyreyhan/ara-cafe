<!-- Bootstrap core JavaScript-->
<script src="{{ asset('admin/vendor/jquery/jquery.min.js')}}"></script>
<script src="{{ asset('admin/vendor/jquery/jquery.min.js')}}"></script>
<!-- Core plugin JavaScript-->
<script src="{{ asset('admin/vendor/jquery-easing/jquery.easing.min.js')}}"></script>
<!-- Page level plugin JavaScript-->
<script src="{{ asset('admin/vendor/datatables/jquery.dataTables.js')}}"></script>
<script src="{{ asset('admin/vendor/datatables/dataTables.bootstrap4.js')}}"></script>
<!-- Custom scripts for all pages-->
<script src="{{ asset('admin/js/sb-admin.min.js')}}"></script>
<!-- Custom scripts for this page-->
<script src="{{ asset('admin/js/sb-admin-datatables.min.js')}}"></script>
